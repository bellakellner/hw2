/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 100418
 Source Host           : localhost:3306
 Source Schema         : musicdb

 Target Server Type    : MySQL
 Target Server Version : 100418
 File Encoding         : 65001

 Date: 10/03/2022 14:32:52
*/

-- ----------------------------
-- Records of music_artist
-- ----------------------------
INSERT INTO `music_artist` VALUES ('Days of Wine and Roses', 'Bill Evans');
INSERT INTO `music_artist` VALUES ('Freeway', 'Aimee Mann');
INSERT INTO `music_artist` VALUES ('These Walls', 'Kendrick Lamar');


-- ----------------------------
-- Records of music_rating
-- ----------------------------
INSERT INTO `music_rating` VALUES (1, 'Amelia-Earhart', 'Freeway', 3);
INSERT INTO `music_rating` VALUES (2, 'Amelia-Earhart', 'Days of Wine and Roses', 4);
INSERT INTO `music_rating` VALUES (3, 'Otto', 'Days of Wine and Roses', 5);
INSERT INTO `music_rating` VALUES (4, 'Amelia-Earhart', 'These Walls', 4);

-- ----------------------------
-- Records of music_song
-- ----------------------------
INSERT INTO `music_song` VALUES (1, 'Aimee Mann', 'Freeway', 'Indie');
INSERT INTO `music_song` VALUES (2, 'Bill Evans', 'Days of Wine and Roses', 'Easy listening');
INSERT INTO `music_song` VALUES (3, 'Kendrick Lamar', 'These Walls', 'Hip-Hop');

-- ----------------------------
-- Records of music_user
-- ----------------------------
INSERT INTO `music_user` VALUES ('Amelia-Earhart', 'Youaom139&yu7');
INSERT INTO `music_user` VALUES ('Otto', 'StarWars2*');
