
Note {

    To run this you need to have a virtual environment, with Django and mysqlclient installed.

    The virtual environment should be created inside the musicproject

    It might already have a virtual environment 'venv' but it was made in windows, hopefully for a window computer it would be easy to activate this environment --- For MAC you are better off deleting this folder and creating a brand new environment. Or you could delete the folder and create a brand new virtual environment for both cases to be sure. 

    I assume you know the commands to perform each of the actions in the console.


}


Step 1) Activate Xammp MySQL

Step 2) Create a database named 'musicdb'

step 3) Activate your virtual environment and make sure that Django and Mysqlclient are isntalled. {

    if you run 'pip freeze' in the virtual environment, you can expect and output as such.

    ```Shell
        pip freeze
        asgiref==3.5.0
        Django==4.0.3           <----- these are the packages
        mysqlclient==2.1.0      <----- you must ensure you have
        PyMySQL==1.0.2
        sqlparse==0.4.2
        tzdata==2021.5
    ```
}

Step 6) Run migrations in the console

step 7) Run migrate in the console

Step 8) Run the server.