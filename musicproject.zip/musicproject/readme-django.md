
Note {

    To run this you need to have a virtual environment, with Django and mysqlclient installed.

    The project may already have a virtual environment 'venv', delete that virtual environment and create a brand new one inside the musicproject folder

    I assume you know the commands to perform each of the actions in the console.

}


Step 1) Activate Xammp MySQL and Apache. 

Step 2) Create a database named 'musicdb' in PhpMyAdmin

step 3) In the console, activate your virtual environment and make sure that Django and Mysqlclient are isntalled. {

    if you run 'pip freeze' in the virtual environment, you can expect and output as such.

    ```Shell
        pip freeze
        asgiref==3.5.0
        Django==4.0.3           <----- these are the packages
        mysqlclient==2.1.0      <----- you must ensure you have
        PyMySQL==1.0.2
        sqlparse==0.4.2
        tzdata==2021.5
    ```
}

Step 6) Run migrations in the console

step 7) Run migrate in the console

Step 8) After running both migrations and migrate, go to PhpMyAdmin and refresh the database 'musicdb', Django should now have added several tables to the database. The ones we are worried about are {

    music_artist
    music_rating
    music_song
    music_user

}

Step 9) Run in the query in the database 'musicdb' the code in the file 'music_databases.sql' {

    When you run this into the query, it adds the data to each of the four tables above for testing. 
}

Step 8) In the console, run the server.